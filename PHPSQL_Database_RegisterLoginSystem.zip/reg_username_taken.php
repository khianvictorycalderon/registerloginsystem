<script>
    disable('#reg-or-login'); enable('#register-form');
</script>
<span class='sub'>WARNING: Username already taken, try another</span>