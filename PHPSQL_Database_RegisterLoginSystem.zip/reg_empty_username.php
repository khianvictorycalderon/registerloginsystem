<script>
    disable('#reg-or-login'); enable('#register-form');
</script>
<span class='sub'>WARNING: Please Enter Your Username</span>