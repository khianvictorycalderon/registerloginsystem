<script>
    disable('#reg-or-login'); enable('#register-form');
</script>
<span class='sub'>WARNING: Password Does Not Match, Try Again!</span>