<script>
    disable('#reg-or-login'); enable('#login-form');
</script>
<span class='sub'>WARNING: Please Enter Your Password</span>