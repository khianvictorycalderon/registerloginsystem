<script>
    disable('#reg-or-login'); enable('#login-form');
</script>
<span class='sub'>WARNING: Invalid Username or Password</span><br>
<span class='details'>(NOTICE: Your Account May Also Be Logged In Other Device)</span>