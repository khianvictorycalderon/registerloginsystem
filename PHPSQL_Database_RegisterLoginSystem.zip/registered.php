<script>
    disable('#reg-or-login');
</script>
<div id="registered">
    <span class='sub'>You are now Registered!</span><br>
    <span class='sub'>You may login now!</span><br>
    <button onclick="disable('#registered'); enable('#reg-or-login')" class="form-btn sub">Home</button>
</div>